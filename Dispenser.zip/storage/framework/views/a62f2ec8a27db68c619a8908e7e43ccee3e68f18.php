<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      
    </div>
    <strong>&copy; <?php echo date('Y')?> - <?php echo e(config('app.name')); ?></strong>
  </footer><?php /**PATH C:\laragon\www\Dispenser\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>