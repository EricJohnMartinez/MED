

<?php $__env->startSection('title', 'Message'); ?>
<?php $__env->startSection('content-header', 'Message'); ?>

<?php $__env->startSection('content'); ?>
<div class="card"><!-- -->
    <div class="card-body">
        <form action="<?php echo e(route('messages.store')); ?>" method="post">
            <?php echo csrf_field(); ?>


            <?php if(Auth::user()->roles=='admin'): ?>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">To</label>
                <select name="to" class="form-control <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="select example">
                <option selected disabled>Select</option>
                <option value="Nurse Station 1">Nurse Station 1</option>
                <option value="Nurse Station 2">Nurse Station 2</option>
                <option value="Nurse Station 3">Nurse Station 3</option>
                <option value="Nurse Station 4">Nurse Station 4</option>
                <option value="Nurse Station 5">Nurse Station 5</option>
                <option value="Nurse Station 6">Nurse Station 6</option>
                <option value="Pharmacy">Pharmacy</option>
                </select>
                <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>

            <?php if(Auth::user()->roles=='nurse'): ?>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">To</label>
                <select name="to" class="form-control <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="select example">
                <option selected disabled>Select</option>
                <option value="Pharmacy">Pharmacy</option>
                </select>
                <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>

            <?php if(Auth::user()->roles=='pharmacy'): ?>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">To</label>
                <select name="to" class="form-control <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="select example">
                <option selected disabled>Select</option>
                <option value="Nurse Station 1">Nurse Station 1</option>
                <option value="Nurse Station 2">Nurse Station 2</option>
                <option value="Nurse Station 3">Nurse Station 3</option>
                <option value="Nurse Station 4">Nurse Station 4</option>
                <option value="Nurse Station 5">Nurse Station 5</option>
                <option value="Nurse Station 6">Nurse Station 6</option>
                </select>
                <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>
           
            <div class="form-group">
                <label for="message">Message</label>
                <textarea  name="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" 
                value="Message / Comment"></textarea>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php if(Auth::user()->roles=='admin'): ?>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">From</label>
                    <select name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="select example">
                    <option selected disabled>Select</option>
                    <option value="Nurse Station 1">Nurse Station 1</option>
                    <option value="Nurse Station 2">Nurse Station 2</option>
                    <option value="Nurse Station 3">Nurse Station 3</option>
                    <option value="Nurse Station 4">Nurse Station 4</option>
                    <option value="Nurse Station 5">Nurse Station 5</option>
                    <option value="Nurse Station 6">Nurse Station 6</option>
                    <option value="Pharmacy">Pharmacy</option>
                    </select>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php endif; ?>

                <?php if(Auth::user()->roles=='nurse'): ?>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">From</label>
                    <select name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="select example">
                    <option selected disabled>Select</option>
                    <option value="Nurse Station 1">Nurse Station 1</option>
                    <option value="Nurse Station 2">Nurse Station 2</option>
                    <option value="Nurse Station 3">Nurse Station 3</option>
                    <option value="Nurse Station 4">Nurse Station 4</option>
                    <option value="Nurse Station 5">Nurse Station 5</option>
                    <option value="Nurse Station 6">Nurse Station 6</option>
                    </select>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php endif; ?>

                <?php if(Auth::user()->roles=='pharmacy'): ?>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">From</label>
                    <select name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="select example">
                    <option selected disabled>Select</option>
                    <option value="Pharmacy">Pharmacy</option>
                    </select>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php endif; ?>


                <button type="submit" class="btn btn-success btn-block btn-lg"><i class="fas fa-check"></i> Submit</button>
            </form>
        </div>
    </div>
         <?php if(Auth::user()->roles=='admin'): ?>
            <div class="card product-list">
                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <!-- -->
                                <th>To</th>
                                <th>Message</th>
                                <th>From</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($message->to); ?></td>
                                    <td><?php echo e($message->message); ?></td>
                                    <td><?php echo e($message->name); ?></td>
                                    <td>
                                     <form action="<?php echo e(route('messages.destroy', $message->id)); ?>" method="POST" style="display: inline-block">
                                     <?php echo csrf_field(); ?>
                                     <?php echo method_field('DELETE'); ?>
                                     <button type="submit" class="btn btn-danger" >Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <?php if(Auth::user()->roles=='nurse'): ?>
            <div class="card product-list">
                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <!-- -->
                                <th>to</th>
                                <th>Message</th>
                                <th>From</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($message->to); ?></td>
                                    <td><?php echo e($message->message); ?></td>
                                    <td><?php echo e($message->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <?php if(Auth::user()->roles=='pharmacy'): ?>
            <div class="card product-list">
                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <!-- -->
                                <th>to</th>
                                <th>Message</th>
                                <th>From</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($message->to); ?></td>
                                    <td><?php echo e($message->message); ?></td>
                                    <td><?php echo e($message->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

<!-- -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Dispenser\resources\views/messages/index.blade.php ENDPATH**/ ?>