

<?php $__env->startSection('title', 'Place Order'); ?>

<?php $__env->startSection('content'); ?>
    <div id="cart"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Dispenser\resources\views/cart/index.blade.php ENDPATH**/ ?>