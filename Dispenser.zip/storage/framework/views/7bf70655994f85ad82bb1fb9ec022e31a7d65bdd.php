

<?php $__env->startSection('title', 'Orders List'); ?>
<?php $__env->startSection('content-header', 'Order List'); ?>
<?php $__env->startSection('content-actions'); ?>
    <?php if(Auth::user()->roles == 'admin'): ?>
        <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-success">Place Order</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <!-- -->
        <div class="card-body">
            <div id="alert" class="alert alert-primary d-none" role="alert">
                New order added. Click here to
                <a class="text-primary" href="javascript:window.location.href=window.location.href">reload </a>
            </div>
            <div class="row">
                <!-- <div class="col-md-3"></div> -->
                <div class="col-md-12">
                    <form action="<?php echo e(route('orders.index')); ?>">
                        <div class="row">
                            <div class="col-md-5">
                                <input type="date" name="start_date" class="form-control"
                                    value="<?php echo e(request('start_date')); ?>" />
                            </div>
                            <div class="col-md-5">
                                <input type="date" name="end_date" class="form-control"
                                    value="<?php echo e(request('end_date')); ?>" />
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary" type="submit"><i class="fas fa-filter"></i> Filter</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <hr>

            <?php if(auth()->user()->roles == 'pharmacy'): ?>
            <?php endif; ?>

            <div class="container-fluid m-0 p-0">
                <form action="<?php echo e(route('orders.index')); ?>" method="GET">
                    <p>
                        Station Numbers
                    </p>
                    <div class="d-flex w-100">

                        <select name="station" class="custom-select">
                            <option <?php if(empty($station) || $station == '1'): ?> selected="selected" <?php endif; ?> value="1">One</option>
                            <option <?php if($station == '2'): ?> selected="selected" <?php endif; ?> value="2">Two</option>
                            <option <?php if($station == '3'): ?> selected="selected" <?php endif; ?> value="3">Three
                            </option>
                            <option <?php if($station == '4'): ?> selected="selected" <?php endif; ?> value="4">Four
                            </option>
                            <option <?php if($station == '5'): ?> selected="selected" <?php endif; ?> value="5">Five
                            </option>
                            <option <?php if($station == '6'): ?> selected="selected" <?php endif; ?> value="6">Six
                            </option>
                        </select>

                        <input class="btn btn-outline-success" type="submit"Search />
                    </div>
                </form>
            </div>


            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Nurse on-Duty</th>
                        
                        <th>Order Placed</th>
                        <th>Order Completed</th>
                    </tr>
                </thead>



                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td>
                                <?php if($order->customer): ?>
                                    <a target="_blank" href="<?php echo e(route('order.viewReceipt', $order->id)); ?>">
                                        <?php echo e($order->getCustomerName()); ?>

                                    </a>
                                <?php else: ?>
                                    Walk-in Customer
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($order->customer->name_of_nurse ?? 'N\A'); ?></td>
                            
                            <td><?php echo e($order->created_at); ?></td>
                            <td><?php echo e($order->updated_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                

            </table>
            <?php echo e($orders->render()); ?>

        </div>
    </div><!-- -->

    <script>
        window.onload = (event) => {
            let loaded = false
            let count = null
            let newCount = null

            async function getCurrentOrderCount() {

                const res = await fetch('/order-count', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });


                const data = await res.json();

                if (loaded == false) {
                    count = data.count
                }

                if (loaded == false && count != null) {
                    newCount = data.count
                }

                loaded = true

            }

            // setInterval(() => {
            //     getCurrentOrderCount()
            //     if (newCount > count) {
            //         if (document.getElementById('alert').classList.contains('d-none')) {
            //             document.getElementById('alert').classList.remove('d-none')
            //         }
            //     } else {
            //         document.getElementById('alert').classList.add('d-none')
            //     }
            // }, 1000);




        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Dispenser\resources\views/orders/index.blade.php ENDPATH**/ ?>