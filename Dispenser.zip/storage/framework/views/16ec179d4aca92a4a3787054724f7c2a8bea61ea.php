

<?php $__env->startSection('title', '24Hr Medication'); ?>
<?php $__env->startSection('content-header', '24Hr Medication'); ?>
<?php $__env->startSection('content-actions'); ?>
    <?php if(Auth::user()->roles == 'nurse'): ?>
        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-success"><i class="fas fa-plus"></i> 24Hr Medication</a>
    <?php endif; ?>
    <?php if(Auth::user()->roles == 'admin'): ?>
        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-success"><i class="fas fa-plus"></i> 24Hr Medication</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container-fluid m-0 p-0">
        <form action="<?php echo e(route('customers.medication')); ?>" method="GET">
            <div class="d-flex w-100">
                <input value="<?php echo e($query); ?>" class="form-control w-100" name="query" type="search" placeholder="Search" aria-label="Search">

                <input class="btn btn-outline-success" type="submit"Search/>
            </div>
        </form>
    </div>

    <div class="card">
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Date</th>
                        <th>Name of Patient</th>
                        <th>Medicines & IV Fluids</th>
                            <th>Requested(Quantity)</th>
                            <th>Dispensed(Quantity)</th>
                        <th>Prepared by (Nurse on Duty)</th>
                        <th>Checked / Revied by (Pharmacist on Duty)</th>
                        <th>Remarks</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customer->updated_at); ?></td>
                            <td><?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?></td>
                            <td><?php echo e($customer->medicines); ?></td>
                            <td><?php echo e($customer->requested); ?></td>
                            <td><?php echo e($customer->dispensed); ?></td>
                            <td><?php echo e($customer->nurse_duty); ?></td>
                            <td><?php echo e($customer->pharmacist_duty); ?></td>
                            <td><?php echo e($customer->daily_remarks); ?></td>
                            <td>
                                <a href="<?php echo e(route('customers.editmedication', $customer)); ?>" class="btn btn-primary"><i
                                        class="fas fa-edit"></i></a>

                                <button class="btn btn-danger btn-delete"
                                    data-url="<?php echo e(route('customers.destroy', $customer)); ?>"><i
                                        class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($customers->render()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $(document).on('click', '.btn-delete', function() {
                $this = $(this);
                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to delete this?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        $.post($this.data('url'), {
                            _method: 'DELETE',
                            _token: '<?php echo e(csrf_token()); ?>'
                        }, function(res) {
                            $this.closest('tr').fadeOut(500, function() {
                                $(this).remove();
                            })
                        })
                    }
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Dispenser\resources\views/customers/medication.blade.php ENDPATH**/ ?>