@extends('layouts.admin')

@section('title', 'Place Order')

@section('content')
    <div id="cart"></div>

@endsection
