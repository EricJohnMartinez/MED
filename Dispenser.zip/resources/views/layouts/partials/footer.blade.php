<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      
    </div>
    <strong>&copy; <?php echo date('Y')?> - {{ config('app.name') }}</strong>
  </footer>